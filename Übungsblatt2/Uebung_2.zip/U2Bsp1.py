"""
Gregor Wagner
U2Bsp1 - TUPLE
Gregor Wagner, 52005240
"""

t = ('P', 'R', 'O', 'G', '1', '_', 'V', 'O')

print(t[-1])
print(t[-2])
t += t
print(t)
print(t.count("O"))