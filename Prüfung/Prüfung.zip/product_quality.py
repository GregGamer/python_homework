

class Produkt():
    def __init__(self, id, quality, vulnerable, cost):
        pass #entfernen
        # ToDo


    def __str__(self):
        pass # entfernen
        #ToDo


def main():
    produktListe = []
    pass #entfernen!

    # Objekte erzeugen und in Liste speichern, etc.
    #ToDO


    




if __name__ == '__main__':
    main()
