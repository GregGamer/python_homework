"""
Gregor Wagner
U1Bsp3 - Multiplier
Gregor Wagner, 52005240
"""

x = input("Zahl1: ")
y = input("Zahl2: ")
z = int(x) * int(y)
print(f"Rechnung {x} * {y} = {z}")
