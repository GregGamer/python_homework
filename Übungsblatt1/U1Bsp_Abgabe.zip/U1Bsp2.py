"""
Gregor Wagner
U1Bsp2 - Text splitting
Gregor Wagner, 52005240
"""

text = "PROG VO bis"

print(text[0:4])
print(text.split()[1])
print(text[-2:])
print(len(text))