"""
Gregor Wagner
U1Bsp1 - Textformatieren
Gregor Wagner, 52005240
"""


print("Twinkle, twinkle, little star,")
print("\t\"How I wonder what you are!\"")
print("\t\tUp above the world so high,")
print("\t\tLike a diamond in the sky.")
print("Twinkle, twinkle, little star,")
print("\t\\How\\ I wonder what you are.")



